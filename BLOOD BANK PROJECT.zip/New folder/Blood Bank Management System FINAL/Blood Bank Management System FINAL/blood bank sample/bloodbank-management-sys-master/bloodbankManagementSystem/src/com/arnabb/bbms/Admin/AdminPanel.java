package com.arnabb.bbms.Admin; // gui 5 / adminPanel

import com.arnabb.bbms.Donor.DeleteDonor;
import com.arnabb.bbms.Login.Login;
import com.arnabb.bbms.Login.Register;

import java.io.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.event.*;

public class AdminPanel extends JFrame implements ActionListener {
    private JLabel background, labelWelcome, title, userlabel, userIDlabel;
    private JButton createAdminButton, deleteDonorButton, deleteAdminButton, regDonorButton, buttonLogout;
    private JPanel panel;
    // private String adId;

    public AdminPanel(String adId) {
        super("BBMS : Admin Panel");
        this.setSize(700, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(
                    "C:\\Users\\talkt\\Downloads\\Blood Bank Management System FINAL\\Blood Bank Management System FINAL\\blood bank sample\\bloodbank-management-sys-master\\assets\\final fr.png"));
            background = new JLabel(new ImageIcon(img));
            background.setBounds(0, 0, 700, 600);
        } catch (IOException e) {
        }

        title = new JLabel("Welcome");
        title.setBounds(250, 60, 400, 150);
        title.setOpaque(false);
        title.setVisible(true);
        title.setFont(new Font("Arial", Font.BOLD, 50));
        title.setForeground(new Color(234, 67, 53));
        panel.add(title);

        userlabel = new JLabel("Admin ID  ");
        userlabel.setBounds(100, 100, 100, 30);
        userlabel.setForeground(new Color(234, 67, 53));
        panel.add(userlabel);

        userIDlabel = new JLabel(adId);
        userIDlabel.setBounds(100, 120, 50, 30);
        panel.add(userIDlabel);

        /*
         * createAdminButton = new JButton("Create Admin");
         * createAdminButton.setBounds(150, 300, 150, 30);
         * createAdminButton.addActionListener(this);
         * panel.add(createAdminButton);
         * 
         * deleteDonorButton = new JButton("Delete Donor Account");
         * deleteDonorButton.setBounds(400, 300, 150, 30);
         * deleteDonorButton.addActionListener(this);
         * panel.add(deleteDonorButton);
         * 
         * deleteAdminButton = new JButton("Delete Admin Account");
         * deleteAdminButton.setBounds(400, 400, 150, 30);
         * deleteAdminButton.addActionListener(this);
         * panel.add(deleteAdminButton);
         * 
         * regDonorButton = new JButton("Register Donor");
         * regDonorButton.setBounds(150, 400, 150, 30);
         * regDonorButton.addActionListener(this);
         * panel.add(regDonorButton);
         * 
         * buttonLogout = new JButton("Sign Out");
         * buttonLogout.setBounds(290, 500, 150, 30);
         * buttonLogout.addActionListener(this);
         * panel.add(buttonLogout);
         */

        panel.add(background);

        this.add(panel);
        // this.adId=adId;

        createAdminButton = createButton("Create Admin", 200, 300);
        panel.add(createAdminButton);

        deleteDonorButton = createButton("Delete Donor", 410, 300);
        panel.add(deleteDonorButton);

        deleteAdminButton = createButton("Delete Admin", 410, 370);
        panel.add(deleteAdminButton);

        regDonorButton = createButton("Register Donor", 200, 370);
        panel.add(regDonorButton);

        buttonLogout = createButton("Sign Out", 290, 440);
        panel.add(buttonLogout);
        panel.add(background);
        this.add(panel);
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 35);
        button.setBackground(new Color(234, 67, 53));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(true);

        button.addActionListener(this);
        return button;
    }

    public void actionPerformed(ActionEvent ae) {
        String buttonClicked = ae.getActionCommand();

        if (buttonClicked.equals(createAdminButton.getText())) {
            String aID = userIDlabel.getText();

            try {
                CreateAdmin ca = new CreateAdmin(aID);
                ca.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(deleteAdminButton.getText())) {

            String aID = userIDlabel.getText();

            try {
                DeleteAdmin da = new DeleteAdmin(aID);
                da.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(deleteDonorButton.getText())) {
            String aID = userIDlabel.getText();

            try {
                DeleteDonor dd = new DeleteDonor(aID);
                dd.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (buttonClicked.equals(regDonorButton.getText())) {

            try {
                Register r = new Register();
                r.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(buttonLogout.getText())) {
            try {
                Login l = new Login();
                l.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
