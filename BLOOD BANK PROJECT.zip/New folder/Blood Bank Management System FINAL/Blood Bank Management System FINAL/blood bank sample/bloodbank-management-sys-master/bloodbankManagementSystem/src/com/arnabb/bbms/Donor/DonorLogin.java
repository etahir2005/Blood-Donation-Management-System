package com.arnabb.bbms.Donor;

import com.arnabb.bbms.DeleteAcc.DeleteAccount;
import com.arnabb.bbms.Search.Update;

import java.io.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.event.*;

public class DonorLogin extends JFrame implements ActionListener {
    private JLabel labelWelcome, background, labelID;
    private JButton viewButton, deleteAccButton, deleteAdminButton, updateButton, buttonLogout;
    private JPanel panel;

    public DonorLogin(String uID) {
        super("Donor Panel");
        this.setSize(700, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(
                    "C:\\Users\\talkt\\Downloads\\Blood Bank Management System FINAL\\Blood Bank Management System FINAL\\blood bank sample\\bloodbank-management-sys-master\\assets\\Screenshot 2024-05-19 102850.png"));
            background = new JLabel(new ImageIcon(img));
            background.setBounds(0, 0, 700, 600);
        } catch (IOException e) {
        }

        labelWelcome = new JLabel("User ID  ");
        labelWelcome.setBounds(230, 50, 120, 30);
        labelWelcome.setForeground(Color.white);
        panel.add(labelWelcome);

        labelID = new JLabel(uID);
        labelID.setBounds(350, 50, 200, 30);
        labelID.setForeground(Color.white);
        panel.add(labelID);

        viewButton = new JButton("View Profile");
        viewButton.setBounds(255, 100, 150, 30);
        viewButton.addActionListener(this);
        panel.add(viewButton);

        deleteAccButton = new JButton("Delete Account");
        deleteAccButton.setBounds(255, 200, 150, 30);
        deleteAccButton.addActionListener(this);
        panel.add(deleteAccButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(255, 300, 150, 30);
        updateButton.addActionListener(this);
        panel.add(updateButton);

        buttonLogout = new JButton("Logout");
        buttonLogout.setBounds(255, 500, 150, 30);
        buttonLogout.addActionListener(this);
        panel.add(buttonLogout);

        panel.add(background);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) {
        String buttonClicked = ae.getActionCommand();

        if (buttonClicked.equals(viewButton.getText())) {
            String lID = labelID.getText();

            try {
                viewDonDetails vd = new viewDonDetails(lID);
                vd.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(deleteAccButton.getText())) {
            String lID = labelID.getText();

            try {
                DeleteAccount delAcc = new DeleteAccount(lID);
                delAcc.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(buttonLogout.getText())) {
            try {
                Donor d = new Donor();
                d.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (buttonClicked.equals(updateButton.getText())) {
            String lID = labelID.getText();

            try {
                Update u = new Update(lID);
                u.setVisible(true);
                this.setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
