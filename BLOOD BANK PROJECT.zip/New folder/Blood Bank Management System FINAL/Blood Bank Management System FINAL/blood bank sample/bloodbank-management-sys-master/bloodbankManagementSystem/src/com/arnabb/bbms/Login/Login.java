package com.arnabb.bbms.Login;//try / gui 2 / login

import com.arnabb.bbms.Admin.AdminPanel;
import com.arnabb.bbms.Home.Homee;

import java.io.*;
import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.imageio.*;
import java.awt.image.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements MouseListener, ActionListener {

	private JLabel title, imgLab, background, userLabel, passLabel;
	private JPanel panel;
	private JTextField userTF;
	private JPasswordField passPF;
	private JButton loginButton, backButton;
	private boolean flag;
	// private JComboBox combo;

	public Login() {

		super("BBMS : Admin Login");
		this.setSize(700, 600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new JPanel();
		panel.setLayout(null);

		BufferedImage img = null;
		try {
			img = ImageIO.read(new File(
					"C:\\Users\\talkt\\Downloads\\Blood Bank Management System FINAL\\Blood Bank Management System FINAL\\blood bank sample\\bloodbank-management-sys-master\\assets\\final fr.png"));
			background = new JLabel(new ImageIcon(img));
			background.setBounds(0, 0, 700, 600);

		} catch (IOException e) {
		}

		title = new JLabel("Administration");
		title.setBounds(218, 60, 400, 200);
		title.setOpaque(false);
		title.setVisible(true);
		title.setFont(new Font("Arial", Font.BOLD, 30));
		title.setForeground(new Color(234, 67, 53));
		panel.add(title);

		userLabel = new JLabel("Admin ID");
		userLabel.setBounds(290, 200, 200, 35);
		userLabel.setForeground(new Color(234, 67, 53));
		panel.add(userLabel);

		userTF = new JTextField();
		userTF.setBounds(220, 230, 200, 35);
		panel.add(userTF);

		passLabel = new JLabel("Password");
		passLabel.setBounds(290, 260, 200, 35);
		passLabel.setForeground(new Color(234, 67, 53));
		panel.add(passLabel);

		passPF = new JPasswordField();
		passPF.setBounds(220, 290, 200, 35);
		// passPF.setEchoChar('*');
		// passPF.setBackground(Color.GRAY);
		panel.add(passPF);

		loginButton = createButton("Sign In", 218, 420);
		panel.add(loginButton);

		backButton = createButton("Exit", 218, 470);
		panel.add(backButton);

		panel.add(background);
		this.add(panel);
	}

	private JButton createButton(String text, int x, int y) {
		JButton button = new JButton(text);
		button.setBounds(x, y, 200, 35);
		button.setBackground(new Color(234, 67, 53));
		button.setForeground(Color.WHITE);
		button.setFocusPainted(false);
		button.setContentAreaFilled(false);
		button.setOpaque(true);
		button.addMouseListener(this);
		button.addActionListener(this);
		return button;
	}
	/*
	 * String []s = {"Adminimistrator", "com.arnabb.bbms.Donor.Donor"};
	 * combo = new JComboBox(s);
	 * combo.setBounds(450,250,150,35);
	 * panel.add(combo);
	 */

	public void mouseEntered(MouseEvent me) {
	}

	public void mouseExited(MouseEvent me) {
	}

	public void mouseReleased(MouseEvent me) {
	}

	public void mousePressed(MouseEvent me) {
	}

	public void mouseClicked(MouseEvent me) {
	}

	public void actionPerformed(ActionEvent ae) {
		String elementText = ae.getActionCommand();

		if (elementText.equals(loginButton.getText())) {

			// System.out.println("hello");
			// flag=true;
			check();

		}

		else if (elementText.equals(backButton.getText())) {
			try {
				Homee h = new Homee();
				h.setVisible(true);
				this.setVisible(false);

			}

			catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			// System.exit(0);
		}
	}

	public void check() {

		String adId = userTF.getText();
		String password = passPF.getText();

		if (adId.length() != 0) {

			if (password.length() != 0) {

				String query = "SELECT AdminID, Password FROM admin_info where AdminID = '" + adId
						+ "' and password = '" + password + "';";
				Connection con = null;// for connection
				Statement st = null;// for query execution
				ResultSet rs = null;// to get row by row result from DB
				System.out.println(query);
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");// load driver
					System.out.println("driver loaded");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/d_reg", "root",
							"BlueKiaSportage616-");
					System.out.println("connection done");// connection with database established
					st = con.createStatement();// create statement
					System.out.println("statement created");
					rs = st.executeQuery(query);// getting result
					System.out.println("results received");

					if (rs.next()) {
						// System.out.println("trrrrryyyyy!!");

						try {

							AdminPanel ah = new AdminPanel(adId);
							ah.setVisible(true);
							this.setVisible(false);
						}

						catch (Exception e) {
							e.printStackTrace();
						}

					} else {
						JOptionPane.showMessageDialog(this, "Please Enter Proper Details");
					}
				}

				catch (Exception ex) {
					System.out.println("Exception : " + ex.getMessage());
				} finally {
					try {
						if (rs != null)
							rs.close();

						if (st != null)
							st.close();

						if (con != null)
							con.close();
					} catch (Exception ex) {
					}
				}
			}

			else {
				JOptionPane.showMessageDialog(this, "Enter Proper Pass");
			}
		}

		else {
			JOptionPane.showMessageDialog(this, "Enter Proper ID");
		}

	}
}
